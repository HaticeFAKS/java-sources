import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int choice=0;
        Scanner scanner=new Scanner(System.in);//choice what are you want doing
        System.out.print("Please enter a number:"); choice=scanner.nextInt();

       String message=" !Hello World ", message1="World!";

       switch (choice){
           case 1:  messageAndElements(message);
               break;

           case 2:System.out.println(message);
                  System.out.println(message.concat(message1));//birleştirir
               break;

           case 3:startsWithEndsWith(message);
               break;

           case 4:getChars(message);
               break;
           case 5:indexLastindexOf(message);
               break;
           case 6:rePlace(message);
               break;
           case 7:subString(message);
           break;
           case 8:trim(message);
               break;
           case 9 :rePlaceAll(message);
               break;
           case 10 :split(message);
               break;
           case 11:toLowerUpperCase(message);
               break;

               /*

               case :(message);
               break;

                */


       }

    }

 static void  messageAndElements(String message ){
     int ptr=0;


     for(int i=0;i<message.length();i++)
     {
         if(message.charAt(i)==' ')  ptr++;
     }
     System.out.println("The number of elements:"+message.length());
     System.out.println("The number of letters:"+ptr);

     for(int i=0;i<message.length(); i++)
     {
         System.out.println("the "+(i+1)+".element is: "+ message.charAt(i));
     }

 }

    static void startsWithEndsWith(String message){
        Scanner scanner=new Scanner(System.in);

        System.out.print("Enter a letter for startsWith method:");String letter=scanner.next();
        System.out.println(message.startsWith(letter));

        System.out.print("Enter a letter for endsWith method:");letter=scanner.next();
        System.out.println(message.endsWith(letter));
    }
    static void getChars(String message){
        char[] part=new char[8];
        part[0]='i'; part[1]='i';
        System.out.println("part is:"+new String(part));
        message.getChars(1, 8,part, 1);
        System.out.println("part after using getChar is:"+new String(part));

    }
    static void indexLastindexOf(String message)
    {
        System.out.println("index of 'l' is:"+message.indexOf('l'));//returned the first l
        System.out.println("index of 'll' is:"+message.indexOf("ll"));
        System.out.println("Last index of 'l' is:"+message.lastIndexOf('l'));//returned the last l
        System.out.println("Last index of 'll' is:"+message.lastIndexOf("ll"));
    }

    static void rePlace(String message)
    {
        System.out.println("Message is:"+message);
        System.out.println("Message is:"+message.replace('l', 'd'));
        System.out.println("Message is:"+message);
    }

    static void subString(String message)
    {
        System.out.println("Message is:"+message);
        System.out.println("Message substring from 10 is:"+message.substring(10));
        System.out.println("Message is:"+message);
        System.out.println("Message substring from 10 to 11 is:"+message.substring(10, 11));
        System.out.println("Message is:"+message);



    }
    static void trim(String message)
    {
        System.out.println("Message is:"+message);
        System.out.println("Message is:"+message.trim());
        System.out.println("Message is:"+message);
    }
    static void rePlaceAll (String message)
    {
        System.out.println("Message is:"+message);
        System.out.println("replace all spaces:"+message.replaceAll(" ","*"));
        System.out.println("Message is:"+message);
        System.out.println("replace all spaces and e:"+message.replaceAll("e ","*"));
        System.out.println("replace all e:"+message.replaceAll("e","*"));
        System.out.println("replace all spaces and !:"+message.replaceAll("! ","*"));
        System.out.println("replace all !:"+message.replaceAll("!","*"));

    }
    static void split (String message)
    {
        System.out.println("Message is:"+message);
        System.out.print("Message's split with regex \" \":");
        for(String word:message.split(" "))
        {
            System.out.print("+"+word+"\t");
        }
        System.out.println("\nMessage is:"+message+"\n\n");
        System.out.print("Message's split with regex \"l\":");
        for(String word:message.split("l"))
        {
            System.out.print("+"+word+"\t");
        }
        System.out.println("\nMessage is:"+message);
    }
    static void toLowerUpperCase(String message)
    {
        System.out.println("Message is:"+message);
        System.out.println("Message after using toLowerCase is:"+message.toLowerCase());
        System.out.println("Message is:"+message);

        System.out.println("\n\nMessage is:"+message);
        System.out.println("Message after using toUpperCase is:"+message.toUpperCase());
        System.out.println("Message is:"+message);


    }

    /*

    static void (String message)
    {
        System.out.println("Message is:"+message);
        System.out.println("Message is:"+message);
        System.out.println("Message is:"+message);
    }

     */


}