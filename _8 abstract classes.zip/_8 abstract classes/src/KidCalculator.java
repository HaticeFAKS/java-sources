public class KidCalculator extends GameCalculator{
    @Override
    public int hesapla() {
        return 200;
    }
}
