public class WomanCalculator extends GameCalculator {
    @Override
    public int hesapla() {

        return 100;
    }
}
