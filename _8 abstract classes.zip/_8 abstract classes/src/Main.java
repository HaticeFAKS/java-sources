public class Main {
    public static void main(String[] args) {


        //Görüldüğü gibi abstract sınıflar
        GameCalculator gameCalculator=new GameCalculator() {
            @Override
           public int hesapla()
            {
                return 180;

            }
        };

        GameCalculator[] array=new GameCalculator[]
                {new KidCalculator(),
                  new ManCalculator(),
                  new WomanCalculator(),
                 gameCalculator
                };
        for(GameCalculator ptr:array)
        {
            System.out.println("Score is:"+ptr.hesapla());
        }
    }
}