public abstract class GameCalculator {
    public abstract int hesapla();

    public final void over()
    {
        System.out.println("Oyun bitti");
    }
}
