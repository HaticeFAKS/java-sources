public class ManCalculator extends GameCalculator{
    @Override
    public int hesapla() {
        return 100;
    }
}
