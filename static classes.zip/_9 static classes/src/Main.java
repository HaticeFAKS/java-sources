public class Main {
    public static void main(String[] args) {



        example.example1.screenInner();
        //static inner sınıfları çağırma şekli
        //sadece bunu çalıştırsam static constructor returned yazmaz.
        // Ama newlarsam bunu kullanıp kullanmasam bile hatta static methodu kullanmasam bile static constructor çalışır.

        example.staticScreen();
        //Newlamıyorsam bunu çalıştırınca yazar çünkü bu static bir method. Diğeri sadece bir sınıftı.
        example classexample=new example();
        classexample.nonStaticScreen();






        //inner class'ı newlemek gereksizdir. Genelde static olan bu sınıflara ve içindekilere sınıf düzeyinde erişilebilir. Yukarıda olduğu gibi.



    }
}