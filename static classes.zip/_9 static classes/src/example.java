public class example {
    //Ana class static olamaz ama içindeki bir class static olabilir.
    static{
        System.out.println("The static cosntructor of the main class returned");
    }
    example(){
        System.out.println("The non static cosntructor of the main class returned");
    }

   void  nonStaticScreen()
    {
        System.out.println("he non static cosntructor will be returned if only this non static method returned");
    }


    static void staticScreen()
    {
        System.out.println("static constructor will be returned when this static method returned");
    }


    //bir classın içinde static class oluşturup kullanmak yaygın bir kullanım değildir.
   public static class example1{

        static{
            System.out.println("The static cosntructor of the inner class returned");
        }

        static void screenInner(){
            System.out.println("This is a inner static class");
        }

    }
}
