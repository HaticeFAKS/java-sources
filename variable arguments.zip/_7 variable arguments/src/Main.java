import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
       Scanner scanner=new Scanner(System.in);

        System.out.println("*"+add(5));
        System.out.println(add(5,10));
        System.out.println(add(5,10,15));
        System.out.println(add(5));
        System.out.println(add(5));

    }

    static int add(int... number)
    {
        int sum=0;

        for(int _number:number)
        {
           sum+=_number;

        }
        return sum;

    }
}