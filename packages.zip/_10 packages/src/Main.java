import Matematik.*; //hepsini ekle demek
import SekilCizme.dortgenler;

public class Main {
    public static void main(String[] args) {

        System.out.println("Logaritma");
        System.out.println("---------");
        System.out.println("Logaritma 3 tabanında 5:"+Logaritma.log(3,5));

        //Matematik.Logaritma eklemeseydim Matematik.Logaritma.log(3,5) şeklinde yazmam gerekirdi.

        System.out.println("Logaritma 5 tabanında 3:"+Logaritma.log(5,3));
        System.out.println("Logaritma 3 tabanında 27:"+Logaritma.log(3,27));
        System.out.println("Logaritma 3 tabanında 24:"+Logaritma.log(3,24));
        System.out.println("Logaritma 5 tabanında 124:"+Logaritma.log(5,124));
        System.out.println("Logaritma 5 tabanında 125:"+Logaritma.log(5,125));
        System.out.println("Logaritma 5 tabanında 126:"+Logaritma.log(5,126));

        System.out.println("\n");

        System.out.println("Dört İşlem");
        System.out.println("----------");
        System.out.println("3+4="+Dortislem.topla(3,4));
        System.out.println("5+7="+Dortislem.topla(5,7));
        System.out.println("6+7+4="+Dortislem.topla(6,7,4));
        System.out.println("3+4+8+9="+Dortislem.topla(3,4,8,9));
        System.out.println("3.65+5.16+8+9="+Dortislem.topla(3.65,5.16,8,9));
        System.out.println("3-4="+Dortislem.cikar(3,4));
        System.out.println("5*7="+Dortislem.carp(5,7));
        System.out.println("3/4="+Dortislem.bol(3,4));
        System.out.println("7/5="+Dortislem.bol(7,5));
        System.out.println("27/3="+Dortislem.bol(27,3));


        System.out.println("\n");

        System.out.println("Şekil çizme");
        System.out.println("----------");
        dortgenler seklim=new dortgenler();
        dortgenler.dikdortgen(5,6);
        seklim.kare(5);
        








    }
}