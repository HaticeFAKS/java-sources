package SekilCizme;

public class dortgenler {

   public static  void dikdortgen(int length1, int length2)
    {
        for(int corrent1=0; corrent1<length2;corrent1++)
        {
            for(int corrent2=0;corrent2<length1;corrent2++){
                System.out.print("*");
            }
            System.out.println(" ");

        }
        System.out.println("\n");
    }

   public void kare(int length1)
    {
        for(int corrent1=0; corrent1<length1;corrent1++)
        {
            for(int corrent2=0;corrent2<length1;corrent2++){
                System.out.print("*");
            }
            System.out.println(" ");

        }
        System.out.println("\n");
    }
}
