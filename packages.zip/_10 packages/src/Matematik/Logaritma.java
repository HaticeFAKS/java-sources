package Matematik;
import java.lang.String;

public class Logaritma {

     public static String log(int number1, int number2){
       int sonuc=0,log;

        for(log=number1; log<=number2; log*=number1){
            sonuc++;
        }

        if(number2==log/number1)  return ("tam "+sonuc);
        else return (""+sonuc);
    }
}
