package Matematik;

public class Dortislem {


    public static double topla(double... number){
        double toplam=0;

        for(double corrent: number){
            toplam+=corrent;
        }
         return toplam;
    }

    public static double cikar(double number1, double number2){
        double sonuc=number1-number2;
        return sonuc;
    }

    public static double carp(double number1, double number2){
        double sonuc=number1*number2;
        return sonuc;
    }

    public static double bol(double number1, double number2){
        double sonuc=number1/number2;
        return  sonuc;
    }





}
